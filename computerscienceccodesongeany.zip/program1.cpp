//Display word corresponding to a digit

#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Input the digit to display in words: ";
	cin>>num;
	switch (num)
		{
		case 0:
		cout<<"zero";break;
		case 1:
		cout<<"one";break;
		case 2:
		cout<<"two";break;
		case 3:
		cout<<"three";break;
		case 4:
		cout<<"four";break;
		case 5:
		cout<<"five";break;
		case 6:
		cout<<"six";break;
		case 7:
		cout<<"seven";break;
		case 8:
		cout<<"eight";break;
		case 9:
		cout<<"nine";break;
		default:
			cout<<"Invalid Input"; break;
			
	}
		return 0;
}
