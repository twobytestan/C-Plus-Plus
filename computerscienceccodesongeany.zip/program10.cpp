//Input a Integer and Check whether it is Positive or Negative.

#include <iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter the integer to check: ";
	cin>>num;
	if(num>0)
	cout<<"\nThe given number is Positive";
else if(num<0)
	cout<<"\nThe given number is Negative";
else
	cout<<"\nThe given number is zero";
return 0;
}
