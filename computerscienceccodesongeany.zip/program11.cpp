//Find the Values of nCr.

#include <iostream>
using namespace std;
long fact(int n) 
{
    long result=1;
    for (int i=1; i<=n; i++) 
    {
        result = result*i;
    }
    return result;
}
int main() 
{
    int n,r,ncr;
    cout<<"Enter the value of n and r (Positive Integer): ";
    cin>>n>>r;
    if ((n>=r)&&(r>=0)) 
    {
		ncr=fact(n)/(fact(r)*fact(n-r));
		cout<<"ncr is: "<<ncr;
	}
    else 
         cout<<"n and r Must be Non-Negative integer and n>r";
return 0;
}
