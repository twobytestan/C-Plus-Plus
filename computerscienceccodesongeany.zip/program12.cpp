//Enter a value and after and before swap.

#include <iostream>
using namespace std;
void swap (int*x, int*y)
{
	int t;
	t=*x;
	*x=*y;
	*y=t;
}
int main()
{
	int a,b;
	cout<<"Enter the values of A and B: ";
	cin>>a>>b;
	cout<<"\nBefore Swap\n";
	cout<<"a= "<<a<<"\t b= "<<b;
	swap(&a,&b);
	cout<<"\nAfter Swap\n";
	cout<<"a= "<<a<<"\t b= "<<b;
return 0;
}
