//Sum of 'n' Natural Numbers

#include<iostream>
using namespace std;
int main()
{
	int n;
	
	cout<<"Enter a Positive integer (a): ";
	cin>>n;
	int sum=0;
	
	for (int i=1; i<=n; i++)
	{
		sum+=i;
	}
	cout<<"The Sum of the First "<<n<<" Natural number is: " <<sum;
	return 0;
}
