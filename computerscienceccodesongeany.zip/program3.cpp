//Input an Integer number and check whether it is palindrome or not

#include<iostream>
using namespace std;
int main()
{
	int n,num,digit,rev=0;
	cout<<"Enter a Positive Number: ";
	cin>>num;
	n=num;
	while (num>0) 
	{
		digit=num%10;
		rev=(rev*10)+digit;
		num=num/10;
	}
	cout<<"The Reverse of the Number is: "<<rev;
	if(n==rev)
	cout<<"\n The Number is a Palindrome.";
	else
	cout<<"\n The number is Not a Palindrome.";
	return 0;
}
	
