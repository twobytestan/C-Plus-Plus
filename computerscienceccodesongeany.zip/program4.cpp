//Check Integer for Prime

#include<iostream>
using namespace std;
int main()
{
	int num;
	bool is_prime=true;
	cout<<"Provide a Positive number: ";
	cin>>num;
	if (num<=1)
	{
		is_prime=false;
	}
else
	{
		for (int i=2; i<=num/2; i++)
		{
			if (num% i==0)
			{
				is_prime=false; break;
			}
		}
	}
	if (is_prime)
	{
		cout<<"Number is prime.";
	}
else
	{
		cout<<"Number is not prime.";
	}
	return 0;
}
