//Input the Three Coefficient of the Quadratic Equations

#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	double a,b,c;
	double root1, root2, real_part,img_part;
	cout<<"Enter a Coefficient of the Quadratic Equation (a,b,c): ";
	cin>>a>>b>>c;
	double disc = b*b-4*a*c;
	if (disc>0)
	{
		root1=(-b+sqrt(disc))/(2*a);
		root2=(-b-sqrt(disc))/(2*a);
		cout<<"Real and Imaginary roots\n";
		cout<<"Root 1: "<<root1<<"\n";
		cout<<"Root 2: "<<root2<<"\n";
	}
else if (disc==0)
	{
		root1= -b/(2*a);
		cout<<"Two Roots are Equal\n";
		cout<<"Root:"<<root1<<"\n";
	}
else 
	{
		real_part=-b/(2*a);
		img_part=sqrt(-disc)/(2*a);
		cout<<"Complex Roots\n";
		cout<<"Root1:"<<real_part<<"+"<<img_part<<"i\n";
		cout<<"Root2:"<<real_part<<"-"<<img_part<<"i\n";
	}
	return 0;
}
	
	
