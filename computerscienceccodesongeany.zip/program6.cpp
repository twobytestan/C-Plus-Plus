//Find the Length of a String

#include<iostream>
using namespace std;
int main()
{
	char str[50];
	int i, length=0;
	cout<<"Enter the String: ";
	cin>>str;
	for (i=0; str [i] !='\0'; ++i)
	{
		length ++;
	}
	cout<<"Length of the String is "<<length;
	return 0;
}
