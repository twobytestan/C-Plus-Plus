//check whether the given numbers is odd or even

#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"Enter a Number: ";
	cin>>num;
	if (num%2==0)
	{
		cout<<"The Given Number is Even";
	}
else
	{
		cout<<"The Given Number is Odd";
	}
	return 0;
}
