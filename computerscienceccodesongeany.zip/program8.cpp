//Sum of the Squares of first N natural numbers

#include<iostream>
using namespace std;
int main()
{
	int num, sum=0,i;
	cout<<"Enter the Limit: ";
	cin>>num;
	for (i=1; i<=num; i++)
	{
		sum=sum+i*i;
	}
	cout<<"Sum of Squares: "<<sum;
	return 0;
}
