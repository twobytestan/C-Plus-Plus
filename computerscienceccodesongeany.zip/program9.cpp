//Sorting of Array

#include<iostream>
using namespace std;
int main()
{
	int heights[20],i,j,n,temp;
	cout<<"Enter the Number of Students: \n";
	cin>>n;
	cout<<"Enter the Heights of the Students: \n";
	for (i=0; i<n; i++)
	cin>>heights[i];
	for (i=0; i<n-1; i++)
	{
		for (j=i+1; j<n; j++)
		{
			if (heights [i]>heights[j])
			{
				temp=heights[i]; heights[i]=heights[j];
				heights[j]=temp;
			}
		}
	}
	cout<<"\nHeights in Ascending order are: \n";
	for (i=0; i<n; i++)
	cout<<heights[i]<<"\n";
	return 0;
}
	
